<template>
 <span>测试</span>
</template>

<script>
export default {
  name: "Test"
}
</script>

<style scoped>

</style>