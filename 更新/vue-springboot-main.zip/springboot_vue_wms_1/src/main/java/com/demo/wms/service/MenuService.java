package com.demo.wms.service;

import com.demo.wms.entity.Menu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wms
 * @since 2023-04-16
 */
public interface MenuService extends IService<Menu> {

}
