package com.demo.wms.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.demo.wms.entity.FileEntity;

/**
 * @author
 * @date
 * @Description
 */

public interface FileService extends IService<FileEntity> {
}
