package com.demo.wms.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.demo.wms.entity.FileEntity;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author
 * @date
 * @Description
 */
@Mapper
public interface FileMapper extends BaseMapper<FileEntity> {
}
